#import "CutViewController.h"

NS_ASSUME_NONNULL_BEGIN

@implementation CutViewController

- (void)viewDidLoad {
    [super viewDidLoad];

    self.view.backgroundColor = UIColor.whiteColor;
}

@end

NS_ASSUME_NONNULL_END
