#import "SecretViewController.h"

NS_ASSUME_NONNULL_BEGIN

@implementation SecretViewController

- (void)viewDidLoad {
    [super viewDidLoad];

    self.view.backgroundColor = UIColor.whiteColor;
}

@end

NS_ASSUME_NONNULL_END
